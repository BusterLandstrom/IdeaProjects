public class Uppgift3 {
    public static void main(String[] args){
        int four = 4;
        int thirteen = 13;

        for( ;four < thirteen ; four++){
            System.out.println(four);
        }
    }
}
